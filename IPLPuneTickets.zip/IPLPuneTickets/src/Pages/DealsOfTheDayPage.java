package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DealsOfTheDayPage {

	WebDriver driver;
	By click_deals_of_the_day= By.xpath("//a[contains(@href,'deals-of-the-day')]");
	By deal_of_the_day=By.xpath(".//*[@id='container']/div/div[1]/div/div/div[1]/div/div[3]/div[1]/a");
	By fashion=By.xpath("//a[contains(text(),'Fashion')]");
	By Mobile=By.xpath("//a[contains(text(),'Mobile')]");
	By Electronics=By.xpath("//a[contains(text(),'Electronics')]");
	By TVs=By.xpath("//a[contains(text(),'TVs')]");
	By Home=By.xpath("//a[contains(text(),'Home')]");
	By Cars=By.xpath("//a[contains(text(),'Cars')]");
	By Books=By.xpath("//a[contains(text(),'Books')]");
	
	By titleofPage=By.xpath("//h2[@class='puxlXr']");


	public DealsOfTheDayPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void click_click_deals_of_the_day()
	{
		driver.findElement(click_deals_of_the_day).click();
	}	
	
	public void click_deal_of_the_day()
	{
		driver.findElement(deal_of_the_day).click();
	}
	
	public void click_fashion()
	{
		driver.findElement(fashion).click();
	}
	
	public void click_Mobile()
	{
		driver.findElement(Mobile).click();
	}
	public void click_Electronics()
	{
		driver.findElement(Electronics).click();
	}
	public void click_TVs()
	{
		driver.findElement(TVs).click();
	}
	public void click_Home()
	{
		driver.findElement(Home).click();
	}
	public void click_Cars()
	{
		driver.findElement(Cars).click();
	}
	
	public String getTitle()
	{
		return (driver.findElement(titleofPage).getText());
	}
	
	
}
