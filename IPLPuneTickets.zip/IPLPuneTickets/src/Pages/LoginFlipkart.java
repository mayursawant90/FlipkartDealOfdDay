package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginFlipkart {

	WebDriver driver;
	By loginclick=By.xpath("//a[text()='Login & Signup']");
	By username=By.xpath("html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input");
	By password=By.xpath("html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input");
	By login=By.xpath("//div[3]/button");
	
	
	public LoginFlipkart(WebDriver driver)
	{
		this.driver=driver;		
	}

	public void checkflow()
	{
	    System.out.print("Hello ");	
	}
	
	public void click_login_link()
	{
		driver.findElement(loginclick).click();
	}
	
	public void setUsername(String username_text)
	{
		driver.findElement(username).sendKeys(username_text);
	}
	
	public void setPassword(String password_text)
	{
		driver.findElement(password).sendKeys(password_text);
	}
	
	public void click_login()
	{
		driver.findElement(login).click();
	}
}
