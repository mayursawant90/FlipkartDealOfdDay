package Test;

import org.testng.annotations.Test;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.testng.Assert;
import org.testng.AssertJUnit;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
//import org.apache.poi.ss.excelant.ExcelAntTest;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


import Add_functionality.Scroll;
import Pages.DealsOfTheDayPage;
import Pages.HomePage;
import Pages.LoginFlipkart;



public class TestCase1_CheckTitle 
{
    WebDriver driver;
    HomePage HPObject;
    LoginFlipkart LFObject;
    DealsOfTheDayPage dotd;
    Scroll scr;
    ExtentReports extent;
    ExtentTest logger;
 
    Logger log=Logger.getLogger("TestCase1_CheckTitle");
    
    @BeforeTest
    public void setup()
    {
    	extent=new ExtentReports(System.getProperty("user.dir")+"/mayur_output/extent_reports.html",true);
    	extent.addSystemInfo("HostName", "Flipkart Machine");
    	extent.addSystemInfo("Environment", "Automation");
    	extent.addSystemInfo("Author", "The Great Mayur Sawant");
    	extent.loadConfig(new File(System.getProperty("user.dir")+"\\src\\Config\\extent_config.xml"));
    	//DOMConfigurator.configure("log4j.xml");
        
    	PropertyConfigurator.configure("log4j.properties");
    	
    	System.setProperty("webdriver.ie.driver","C:\\TestNG\\IEDriverServer.exe");
        
    	DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
    	
    	capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
    	//@SuppressWarnings("deprecation")
    	driver = new InternetExplorerDriver(); 

    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	driver.manage().deleteAllCookies();
    	log.warn("opening webiste");
    	driver.get("https://www.flipkart.com/"); 
    	log.warn("Deleting cookies");
    	driver.manage().deleteAllCookies();
    }
    
    @Test(priority=0)
    public void TestCase1()
    {
        logger=extent.startTest("TestCase1");
    	HPObject=new HomePage(driver);
    	String HomePageTitle=HPObject.getTitle();
    	log.warn("Printing website title");
    	System.out.println(HomePageTitle);
    	AssertJUnit.assertEquals("Online Shopping Site for Mobiles, Fashion, Books, Electronics, Home Appliances and More",HomePageTitle);
        logger.log(LogStatus.PASS,"Test case passed is Testcase1");
    }
    
    @Test(priority=1, enabled=false)
    public void TestCase2()
    {
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        //Alert alert=driver.switchTo().alert();
    	LFObject=new LoginFlipkart(driver);
    	LFObject.checkflow();
    	LFObject.click_login_link();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	LFObject.setUsername("mrsawant1@gmail.com");
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	LFObject.setPassword("Navodaya.@420");
    	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
    	LFObject.click_login();
    	driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

    	String LoginPageTitle=HPObject.getTitle();

    	System.out.println(LoginPageTitle);
    	AssertJUnit.assertEquals("Online Shopping Site for Mobiles, Fashion, Books, Electronics, Home Appliances and More",LoginPageTitle);
         
    }
    
    @Test(priority=2)
    public void Testcase3()
    {
    	dotd=new DealsOfTheDayPage(driver);
    	dotd.click_click_deals_of_the_day();
    	//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	
    	dotd.click_deal_of_the_day();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
		js.executeScript("window.scrollBy(0,1000)");
    	//scr.scrolling(driver);
		String title=dotd.getTitle();
		AssertJUnit.assertEquals("Deals of the Day",title);
    	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);

    	for(int i=1;i<=19;i++)
    	{
    		String pro_path=".//*[@id='container']/div/div[1]/div/div/div[2]/div[1]/div/div[2]/div/div["+i+"]/div/a/div[2]"; 
    		String price_path=".//*[@id='container']/div/div[1]/div/div/div[2]/div[1]/div/div[2]/div/div["+i+"]/div/a/div[3]"; 
    		if(driver.findElements(By.xpath(pro_path)).size()!= 0 && driver.findElements(By.xpath(price_path)).size()!= 0)
    		{
    		String product=driver.findElement(By.xpath(pro_path)).getText();
    		String price=driver.findElement(By.xpath(price_path)).getText();
    		System.out.println(product+" : "+price );
    		//Assert.assertTrue(price.contains("10% Off"));
    		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    		}
    	}
    	
    	
    	
/*    	dotd.click_Electronics();
    	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

    	dotd.click_Cars();
    	dotd.click_fashion();
    	dotd.click_Home();
    	dotd.click_TVs();*/
    	
    	
    }
    
    @AfterTest
    public void destroy() 
    {
    	extent.endTest(logger);
    	extent.flush();
    	extent.close();
    	driver.close();
    }
    
}
