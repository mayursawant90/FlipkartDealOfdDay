import org.testng.annotations.Test;
import org.apache.log4j.Logger;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileReader;

import java.util.List;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class CheckPuneTickets 
{

	@Test
	public void test_tickets()
	{
    System.setProperty("webdriver.ie.driver","C:\\Users\\Mayur_Sawant\\Downloads\\IEDriverServer_Win32_3.9.0\\IEDriverServer.exe");
    
	DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	
	capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	@SuppressWarnings("deprecation")
	InternetExplorerDriver driver = new InternetExplorerDriver(capabilities); 

	driver.get("https://in.bookmyshow.com/sports/cricket/t20-premier-league"); 
	for(int i=1;i<=8;i++)
		{	
			//WebElement wb=driver.findElement(By.xpath("html/body/div[3]/div/div[3]/div/div/a["+i+"]/div/div[1]/div[1]"));
			Boolean isPresent = driver.findElement(By.xpath("html/body/div[3]/div/div[3]/div/div/a["+i+"]/div/div[1]/div[1]")).isDisplayed();
			if(Boolean.TRUE.equals(isPresent))
			{	
				String TeamName=driver.findElement(By.xpath("html/body/div[3]/div/div[3]/div/div/a["+i+"]/div/div[1]/div[1]")).getText();
	            System.out.println(TeamName);
			}    
		}
	}
	
}