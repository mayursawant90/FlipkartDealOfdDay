package Add_functionality;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
public class Scroll {

	public void scrolling(WebDriver driver)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
	}
	
}
